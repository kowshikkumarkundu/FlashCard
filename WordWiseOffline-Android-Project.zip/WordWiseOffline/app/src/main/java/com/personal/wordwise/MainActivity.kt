package com.personal.wordwise

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.random.Random

private val Green = Color(0xFF168A45)
private val Pale = Color(0xFFE8F6EA)
private val Ink = Color(0xFF17251D)

data class Word(
    val id: Long = 0, val word: String, val english: String = "", val bangla: String = "",
    val synonyms: String = "", val antonyms: String = "", val pos: String = "",
    val sentence1: String = "", val sentence2: String = "", val image: String = "",
    val favorite: Boolean = false, val status: String = "NEW", val nextReview: Long = 0,
    val interval: Int = 0, val createdDay: Long = 0
)

class WordDb(context: Context) : SQLiteOpenHelper(context, "wordwise.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE words(
            id INTEGER PRIMARY KEY AUTOINCREMENT, word TEXT NOT NULL, english TEXT, bangla TEXT,
            synonyms TEXT, antonyms TEXT, pos TEXT, sentence1 TEXT, sentence2 TEXT, image TEXT,
            favorite INTEGER DEFAULT 0, status TEXT DEFAULT 'NEW', nextReview INTEGER DEFAULT 0,
            interval INTEGER DEFAULT 0, createdDay INTEGER DEFAULT 0)""")
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)")
        db.execSQL("INSERT INTO settings(key,value) VALUES('target','5')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun all(): List<Word> {
        val out = mutableListOf<Word>()
        readableDatabase.rawQuery("SELECT * FROM words ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += Word(
                c.getLong(0), c.getString(1), c.getString(2) ?: "", c.getString(3) ?: "",
                c.getString(4) ?: "", c.getString(5) ?: "", c.getString(6) ?: "",
                c.getString(7) ?: "", c.getString(8) ?: "", c.getString(9) ?: "",
                c.getInt(10) == 1, c.getString(11) ?: "NEW", c.getLong(12),
                c.getInt(13), c.getLong(14))
        }
        return out
    }
    fun save(w: Word): Long {
        val v = ContentValues().apply {
            put("word", w.word.trim()); put("english", w.english); put("bangla", w.bangla)
            put("synonyms", w.synonyms); put("antonyms", w.antonyms); put("pos", w.pos)
            put("sentence1", w.sentence1); put("sentence2", w.sentence2); put("image", w.image)
            put("favorite", if (w.favorite) 1 else 0); put("status", w.status)
            put("nextReview", w.nextReview); put("interval", w.interval); put("createdDay", w.createdDay)
        }
        return if (w.id == 0L) writableDatabase.insert("words", null, v)
        else { writableDatabase.update("words", v, "id=?", arrayOf(w.id.toString())); w.id }
    }
    fun toggleFavorite(w: Word) { writableDatabase.execSQL("UPDATE words SET favorite=? WHERE id=?", arrayOf(if (w.favorite) 0 else 1, w.id)) }
    fun target(): Int = readableDatabase.rawQuery("SELECT value FROM settings WHERE key='target'", null).use { if (it.moveToFirst()) it.getString(0).toIntOrNull() ?: 5 else 5 }
    fun setTarget(n: Int) { writableDatabase.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('target',?)", arrayOf(n.toString())) }
    fun delete(w: Word) { writableDatabase.delete("words", "id=?", arrayOf(w.id.toString())) }
    fun review(w: Word, result: String) {
        val today = System.currentTimeMillis() / 86400000L
        val nextInterval = when (result) {
            "MEMORIZED" -> when (w.interval) { 0 -> 1; 1 -> 3; 3 -> 7; 7 -> 15; else -> 30 }
            "HINT" -> 1
            else -> 1
        }
        val status = result
        writableDatabase.execSQL("UPDATE words SET status=?, interval=?, nextReview=? WHERE id=?",
            arrayOf(status, if (result == "FORGOT") 0 else nextInterval, today + nextInterval, w.id))
    }
    fun backupTo(uri: Uri, context: Context) {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            ZipOutputStream(out).use { zip ->
                val dbFile = context.getDatabasePath("wordwise.db")
                if (dbFile.exists()) { zip.putNextEntry(ZipEntry("wordwise.db")); dbFile.inputStream().copyTo(zip); zip.closeEntry() }
                val images = File(context.filesDir, "images")
                images.listFiles()?.forEach { f ->
                    zip.putNextEntry(ZipEntry("images/${f.name}")); f.inputStream().copyTo(zip); zip.closeEntry()
                }
            }
        }
    }
    fun restoreFrom(uri: Uri, context: Context) {
        close()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var e = zip.nextEntry
                while (e != null) {
                    val dest = if (e.name == "wordwise.db") context.getDatabasePath("wordwise.db")
                        else if (e.name.startsWith("images/") && !e.name.contains("..")) File(context.filesDir, e.name)
                        else null
                    if (dest != null) {
                        dest.parentFile?.mkdirs()
                        FileOutputStream(dest).use { zip.copyTo(it) }
                    }
                    zip.closeEntry(); e = zip.nextEntry
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { WordWiseApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordWiseApp() {
    val context = LocalContext.current
    val db = remember { WordDb(context) }
    var refresh by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Word?>(null) }
    var practice by remember { mutableStateOf<List<Word>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf(false) }
    var target by remember { mutableIntStateOf(db.target()) }
    var randomCount by remember { mutableStateOf("30") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Word?>(null) }
    var pickedImagePath by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val dir = File(context.filesDir, "images").apply { mkdirs() }
            val file = File(dir, "img_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            pickedImagePath = file.absolutePath
        }
    }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) db.backupTo(uri, context)
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { db.restoreFrom(uri, context); refresh++ }
    }

    val words = remember(refresh) { db.all() }
    val today = System.currentTimeMillis() / 86400000L
    val todayNew = words.count { it.createdDay == today }
    val due = words.filter { it.nextReview in 1..today }
    val favs = words.filter { it.favorite }
    val todayWords = words.filter { it.createdDay == today }
    val current = practice.getOrNull(index)

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color(0xFFF6FAF6), surface = Color.White)) {
        Scaffold(
            containerColor = Color(0xFFF6FAF6),
            topBar = { if (page != "Home") TopAppBar(title = { Text(page, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = { page = "Home" }) { Icon(Icons.Default.ArrowBack, null) } }) },
            bottomBar = {
                if (page in listOf("Home", "Dictionary", "Revision", "Favourite", "More")) NavigationBar {
                    listOf("Home", "Dictionary", "Revision", "Favourite", "More").forEach { p ->
                        NavigationBarItem(selected = page == p, onClick = { page = p }, icon = {
                            Icon(when(p) { "Home" -> Icons.Default.Home; "Dictionary" -> Icons.Default.MenuBook; "Revision" -> Icons.Default.Refresh; "Favourite" -> Icons.Default.Favorite; else -> Icons.Default.MoreHoriz }, null)
                        }, label = { Text(p) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when (page) {
                    "Home" -> HomeScreen(target, todayNew, due.size, words.size, favs.size,
                        onAdd = { editing = null; showAdd = true },
                        onPractice = { list, title -> practice = list.shuffled(); index = 0; hint = false; answer = false; page = "Practice: $title" },
                        onNavigate = { page = it })
                    "Dictionary" -> WordList(words, db, refresh) { w -> selected = w; page = "Word Details" }
                    "Favourite" -> Column {
                        WordList(favs, db, refresh) { w -> selected = w; page = "Word Details" }
                        Button(onClick = { practice = favs.shuffled(); index = 0; page = "Practice: Favourite" }, enabled = favs.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Practice favourites") }
                    }
                    "Revision" -> Column {
                        Text("${due.size} words due for revision", color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                        Button(onClick = { practice = due.shuffled(); index = 0; page = "Practice: Revision" }, enabled = due.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Start revision") }
                        WordList(due, db, refresh) { w -> selected = w; page = "Word Details" }
                    }
                    "More" -> MoreScreen(target, onTarget = { target = it; db.setTarget(it); refresh++ },
                        onBackup = { backupPicker.launch("WordWise-backup.zip") }, onRestore = { restorePicker.launch(arrayOf("application/zip", "application/octet-stream")) },
                        onStatus = { page = it })
                    "Memorized", "Hints Needed", "Forgot" -> {
                        val key = when(page) { "Memorized" -> "MEMORIZED"; "Hints Needed" -> "HINT"; else -> "FORGOT" }
                        WordList(words.filter { it.status == key }, db, refresh) { w -> selected = w; page = "Word Details" }
                    }
                    "Practice: Today's Words", "Practice: Revision", "Practice: Random", "Practice: Favourite" -> {
                        PracticeScreen(current, index, practice.size, hint, answer,
                            onHint = { hint = true }, onShow = { answer = true },
                            onRate = { result ->
                                current?.let { db.review(it, result) }
                                if (index + 1 < practice.size) { index++; hint = false; answer = false }
                                else { page = "Home"; refresh++ }
                            }, onExit = { page = "Home"; refresh++ })
                    }
                    "Word Details" -> selected?.let { WordDetail(it, onFav = { db.toggleFavorite(it); refresh++ }, onEdit = { editing = it; showAdd = true }, onDelete = { db.delete(it); selected = null; page = "Dictionary"; refresh++ }) }
                    else -> Text("Select a section")
                }
            }
        }
    }

    if (showAdd) AddWordDialog(editing, pickedImagePath, onDismiss = { showAdd = false; pickedImagePath = "" }, onPickImage = {
        imagePicker.launch(arrayOf("image/*"))
    }, onSave = { w ->
        val day = if (editing == null) today else editing!!.createdDay
        db.save(w.copy(id = editing?.id ?: 0, createdDay = day))
        showAdd = false; selected = null; pickedImagePath = ""; refresh++
    })
}

@Composable
fun HomeScreen(target: Int, todayNew: Int, due: Int, total: Int, favorites: Int,
               onAdd: () -> Unit, onPractice: (List<Word>, String) -> Unit, onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val db = remember { WordDb(context) }
    val all = remember(total, todayNew) { db.all() }
    val today = System.currentTimeMillis() / 86400000L
    val todays = all.filter { it.createdDay == today }
    var randomCount by remember { mutableStateOf("30") }
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("My Vocabulary", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink); Text("Learn · Practice · Remember", color = Color.Gray) }
            Icon(Icons.Default.Spa, contentDescription = null, tint = Green, modifier = Modifier.size(34.dp))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("🎯  Daily Target", fontWeight = FontWeight.Bold)
                Text("$todayNew / $target words", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Green)
                LinearProgressIndicator(progress = { (todayNew.toFloat() / target).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                if (todayNew >= target) Text("Target completed! Extra words are welcome.", color = Green)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Today's Revision", "$due due", Modifier.weight(1f), Color(0xFFFFF3DB))
            StatCard("Dictionary", "$total words", Modifier.weight(1f), Pale)
        }
        Text("Quick Actions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionCard("Add Word", Icons.Default.Add, Modifier.weight(1f), onAdd)
            ActionCard("Today's Words", Icons.Default.PlayArrow, Modifier.weight(1f)) { onPractice(todays, "Today's Words") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(randomCount, { randomCount = it.filter(Char::isDigit) }, modifier = Modifier.weight(0.8f),
                label = { Text("Random count") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            ActionCard("Random Practice", Icons.Default.Shuffle, Modifier.weight(1f)) {
                val count = randomCount.toIntOrNull()?.coerceAtLeast(1) ?: 30
                onPractice(all.shuffled().take(count), "Random")
            }
            ActionCard("Favourite", Icons.Default.Favorite, Modifier.weight(1f)) { onNavigate("Favourite") }
        }
        Text("Word Status", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusCard("Memorized", all.count { it.status == "MEMORIZED" }.toString(), Modifier.weight(1f)) { onNavigate("Memorized") }
            StatusCard("Hints", all.count { it.status == "HINT" }.toString(), Modifier.weight(1f)) { onNavigate("Hints Needed") }
            StatusCard("Forgot", all.count { it.status == "FORGOT" }.toString(), Modifier.weight(1f)) { onNavigate("Forgot") }
        }
        Button(onClick = { onPractice(all.shuffled().take(30), "Random") }, modifier = Modifier.fillMaxWidth()) { Text("Practice 30 Random Words") }
    }
}

@Composable fun StatCard(title: String, value: String, modifier: Modifier, bg: Color) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = bg)) { Column(Modifier.padding(14.dp)) { Text(title, color = Color.DarkGray); Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp) } }
}
@Composable fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, action: () -> Unit) {
    Card(modifier.clickable { action() }, colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Green); Text(title, fontWeight = FontWeight.SemiBold) } }
}
@Composable fun StatusCard(title: String, value: String, modifier: Modifier, action: () -> Unit) {
    Card(modifier.clickable { action() }, colors = CardDefaults.cardColors(containerColor = Pale)) { Column(Modifier.padding(10.dp)) { Text(title, fontSize = 12.sp); Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold) } }
}

@Composable
fun WordList(list: List<Word>, db: WordDb, refresh: Int, onClick: (Word) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search words") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(list.filter { it.word.contains(query, true) }) { w ->
                Card(Modifier.fillMaxWidth().clickable { onClick(w) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(w.word, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(w.bangla.ifBlank { w.english }, color = Color.Gray, maxLines = 1) }
                        IconButton(onClick = { db.toggleFavorite(w) }) { Icon(if (w.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (w.favorite) Color.Red else Green) }
                    }
                }
            }
        }
    }
}

@Composable
fun PracticeScreen(w: Word?, index: Int, total: Int, hint: Boolean, answer: Boolean,
                   onHint: () -> Unit, onShow: () -> Unit, onRate: (String) -> Unit, onExit: () -> Unit) {
    if (w == null) { Text("No words to practice."); Button(onClick = onExit) { Text("Back") }; return }
    Column(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Practice", fontWeight = FontWeight.Bold); Text("${index + 1} / $total", color = Green) }
        Card(Modifier.fillMaxWidth().weight(1f).padding(vertical = 16.dp), colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(26.dp)) {
            Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (answer) {
                    if (w.image.isNotBlank()) {
                        val bmp = remember(w.image) { BitmapFactory.decodeFile(w.image) }
                        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().height(130.dp))
                    }
                    Text(w.word, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Info("English Meaning", w.english); Info("বাংলা অর্থ", w.bangla); Info("Part of Speech", w.pos)
                    Info("Synonyms", w.synonyms); Info("Antonyms", w.antonyms)
                    if (w.sentence1.isNotBlank()) Info("Sentence 1", w.sentence1)
                    if (w.sentence2.isNotBlank()) Info("Sentence 2", w.sentence2)
                } else {
                    Text(w.word, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Text("Try to remember the meaning", color = Color.Gray, modifier = Modifier.padding(top = 20.dp))
                    if (hint) {
                        if (w.sentence1.isNotBlank()) Text(w.sentence1, modifier = Modifier.padding(top = 22.dp), fontSize = 18.sp)
                        if (w.sentence2.isNotBlank()) Text(w.sentence2, modifier = Modifier.padding(top = 8.dp), fontSize = 18.sp)
                    }
                }
            }
        }
        if (!answer) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onHint, modifier = Modifier.weight(1f)) { Text(if (hint) "Hint shown" else "💡 Hint") }
            Button(onClick = onShow, modifier = Modifier.weight(1f)) { Text("Show Answer") }
        } else {
            Text("How well did you remember?", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { onRate("MEMORIZED") }, modifier = Modifier.weight(1f)) { Text("Memorized") }
                Button(onClick = { onRate("HINT") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A52B))) { Text("Needed Hint") }
                Button(onClick = { onRate("FORGOT") }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD9534F))) { Text("Forgot") }
            }
        }
    }
}

@Composable fun Info(label: String, value: String) { if (value.isNotBlank()) Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(value, color = Ink) } }

@Composable
fun WordDetail(w: Word, onFav: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(w.word, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            IconButton(onClick = onFav) { Icon(if (w.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color.Red) }
        }
        if (w.image.isNotBlank()) {
            val bmp = remember(w.image) { BitmapFactory.decodeFile(w.image) }
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().height(170.dp))
        }
        Info("English Meaning", w.english); Info("বাংলা অর্থ", w.bangla); Info("Part of Speech", w.pos)
        Info("Synonyms", w.synonyms); Info("Antonyms", w.antonyms); Info("Sentence 1", w.sentence1); Info("Sentence 2", w.sentence2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onEdit, modifier = Modifier.weight(1f)) { Text("Edit") }; OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("Delete") } }
    }
}

@Composable
fun AddWordDialog(existing: Word?, pickedImagePath: String, onDismiss: () -> Unit, onPickImage: () -> Unit, onSave: (Word) -> Unit) {
    var word by remember { mutableStateOf(existing?.word ?: "") }
    var english by remember { mutableStateOf(existing?.english ?: "") }
    var bangla by remember { mutableStateOf(existing?.bangla ?: "") }
    var syn by remember { mutableStateOf(existing?.synonyms ?: "") }
    var ant by remember { mutableStateOf(existing?.antonyms ?: "") }
    var pos by remember { mutableStateOf(existing?.pos ?: "") }
    var s1 by remember { mutableStateOf(existing?.sentence1 ?: "") }
    var s2 by remember { mutableStateOf(existing?.sentence2 ?: "") }
    var image by remember(existing?.id) { mutableStateOf(existing?.image ?: "") }
    LaunchedEffect(pickedImagePath) { if (pickedImagePath.isNotBlank()) image = pickedImagePath }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Add New Word" else "Edit Word") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                item { OutlinedTextField(word, { word = it }, label = { Text("Word *") }, singleLine = true) }
                item {
                    OutlinedButton(onClick = onPickImage, modifier = Modifier.fillMaxWidth()) {
                        Text(if (image.isBlank()) "＋ Add Image (Optional)" else "Change Image")
                    }
                    if (image.isNotBlank()) {
                        val bmp = remember(image) { BitmapFactory.decodeFile(image) }
                        if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().height(110.dp))
                        TextButton(onClick = { image = "" }) { Text("Remove image") }
                    }
                }
                item { OutlinedTextField(english, { english = it }, label = { Text("English Meaning") }) }
                item { OutlinedTextField(bangla, { bangla = it }, label = { Text("বাংলা অর্থ") }) }
                item { OutlinedTextField(syn, { syn = it }, label = { Text("Synonyms") }) }
                item { OutlinedTextField(ant, { ant = it }, label = { Text("Antonyms") }) }
                item { OutlinedTextField(pos, { pos = it }, label = { Text("Parts of Speech") }) }
                item { OutlinedTextField(s1, { s1 = it }, label = { Text("Sentence 1") }) }
                item { OutlinedTextField(s2, { s2 = it }, label = { Text("Sentence 2 (Optional)") }) }
            }
        },
        confirmButton = { TextButton(onClick = { if (word.isNotBlank()) onSave(Word(id = existing?.id ?: 0, word = word, english = english, bangla = bangla, synonyms = syn, antonyms = ant, pos = pos, sentence1 = s1, sentence2 = s2, image = image, favorite = existing?.favorite ?: false, status = existing?.status ?: "NEW", nextReview = existing?.nextReview ?: 0, interval = existing?.interval ?: 0, createdDay = existing?.createdDay ?: 0)) }, enabled = word.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun MoreScreen(target: Int, onTarget: (Int) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onStatus: (String) -> Unit) {
    var value by remember(target) { mutableStateOf(target.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Daily Word Target") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        Button(onClick = { value.toIntOrNull()?.takeIf { it > 0 }?.let(onTarget) }, modifier = Modifier.fillMaxWidth()) { Text("Save Target") }
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("Backup Data (ZIP)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("Restore Backup") }
        Text("Word Status", fontWeight = FontWeight.Bold)
        listOf("Memorized", "Hints Needed", "Forgot").forEach { TextButton(onClick = { onStatus(it) }) { Text(it) } }
        Text("All data stays on this device. No API or account required.", color = Color.Gray)
    }
}
