# WordWise Offline

A personal, fully offline Android vocabulary memorization app.

## Build APK with GitHub Actions
1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build WordWise APK** and click **Run workflow** (or push to `main`).
4. Download the `WordWise-debug-apk` artifact from the completed workflow.

## Build locally
Requires JDK 17, Android SDK (platform 35), and Gradle 8.9:
```bash
gradle assembleDebug
```

## Features
- Add words with optional meanings, synonyms, antonyms, part of speech, two examples and an image.
- Daily new-word target; target words are added directly to the dictionary. Extra words are allowed.
- Flashcards with sentence hints and full answer reveal.
- Rate each review as Memorized, Needed Hint, or Forgot.
- Due review schedule: 1, 3, 7, 15 and 30 days; missed words return sooner.
- Random practice from the full dictionary or favourites.
- Separate status filters and favourites.
- Offline ZIP backup and restore using Android document picker.

All vocabulary data and selected images are stored on-device. No account, API or cloud service is used.
